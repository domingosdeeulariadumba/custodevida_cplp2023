/*Base de dados referente aos pre�os dos principais produtos  e servi�os em pa�ses da CPLP,
com dados dispon�veis, para o ano de 2023, em USD. FONTE: preciosmundi.com*/

/*Cria��o da base de dados e das tabelas*/
CREATE DATABASE custodevida_cplp2023;

CREATE TABLE angola (
code VARCHAR (35) DEFAULT 'AO',
continente VARCHAR (35) DEFAULT '�frica',
produto VARCHAR (50),
categoria VARCHAR (50),
preco REAL);

CREATE TABLE cabo_verde (
code VARCHAR (35) DEFAULT 'CV',
continente VARCHAR (35) DEFAULT '�frica',
produto VARCHAR (50),
categoria VARCHAR (50),
preco REAL);

CREATE TABLE mocambique (
code VARCHAR (35) DEFAULT 'MZ',
continente VARCHAR (35) DEFAULT '�frica',
produto VARCHAR (50),
categoria VARCHAR (50),
preco REAL);

CREATE TABLE portugal (
code VARCHAR (35) DEFAULT 'PT',
continente VARCHAR (35) DEFAULT 'Europa',
produto VARCHAR (50),
categoria VARCHAR (50),
preco REAL);

CREATE TABLE brasil (
code VARCHAR (35) DEFAULT 'BR',
continente VARCHAR (35) DEFAULT 'Am�rica do Sul',
produto VARCHAR (50),
categoria VARCHAR (50),
preco REAL);

/*Inser��o dos dados nas tabelas criadas*/
		/*Angola*/
INSERT INTO angola (produto, categoria, preco)
VALUES ('Cerveja Importada (330 mL)', 'Alimentos nos Supermercados', 0.87),
('Cerveja Nacional (0.5 L)', 'Alimentos nos Supermercados', 0.69),
('Garrafa de Vinho (qualidade m�dia)', 'Alimentos nos Supermercados', 9.06),
('Garrafa de �gua (1.5 L)', 'Alimentos nos Supermercados', 0.55),
('Alface (unidade)', 'Alimentos nos Supermercados', 1.12),
('Cebolas (1 kg)', 'Alimentos nos Supermercados', 1.71),
('Batatas (1 kg)', 'Alimentos nos Supermercados', 1.66),
('Tomates (1 kg)', 'Alimentos nos Supermercados', 1.95),
('Laranjas (1 kg)', 'Alimentos nos Supermercados', 4.33),
('Bananas (1 kg)', 'Alimentos nos Supermercados', 0.83),
('Ma��s (1 kg)', 'Alimentos nos Supermercados', 2.96),
('Queijo Fresco (1 kg)', 'Alimentos nos Supermercados', 10.64),
('Ovos (d�zia)', 'Alimentos nos Supermercados', 2.76),
('Arroz (1 kg)', 'Alimentos nos Supermercados', 0.89),
('P�o (1 kg)', 'Alimentos nos Supermercados', 1.66),
('Leite (1 L)', 'Alimentos nos Supermercados', 1.5);

INSERT INTO angola (produto, categoria, preco)
VALUES ('Garrafa de �gua (330 mL)', 'Alimentos em Restaurantes', 1.16),
('Coca-Cola/Pepsi (330 mL)', 'Alimentos em Restaurantes', 1.77),
('Capuccino', 'Alimentos em Restaurantes', 3.74),
('Cerveja Importada (330 mL)', 'Alimentos em Restaurantes', 1.28),
('Cerveja Nacional (0.5 L)', 'Alimentos em Restaurantes', 1.95),
('Menu McDonalds, Burger Kings ou similares', 'Alimentos em Restaurantes', 8.47),
('Almo�o para Dois (2 pratos + sobremesa)', 'Alimentos em Restaurantes', 60.49),
('Almo�o em Restaurante Barato)', 'Alimentos em Restaurantes', 7.88);


INSERT INTO angola (produto, categoria, preco)
VALUES ('Sapato de Couro Masculino', 'Vestu�rio e Cal�ados', 238.22),
('T�nis Desportivos de Marca (Nike, Adidas, etc.)', 'Vestu�rio e Cal�ados', 252.81),
('Vestido (unidade)', 'Vestu�rio e Cal�ados', 150.34),
('Cal�a Jeans', 'Vestu�rio e Cal�ados', 95.96);

INSERT INTO angola (produto, categoria, preco)
VALUES ('Volkswagen Golf 1.4 de 90 kW (ou equivalente)', 'Transportes', 20938.95),
('Gasolina (1 L)', 'Transportes e Servi�os', 0.35),
('Uma Hora de T�xi (Bandeira 1)', 'Transportes', 8.08),
('T�xi Tarifa ao km (Bandeira 1)', 'Transportes', 1.67),
('Valor Inicial (Bandeira 1)', 'Transportes', 1.67),
('Passe de Transporte P�blico Mensal', 'Transportes', 31.72),
('Bilhete Unit�rio em Transporte P�blico', 'Transportes', 0.35);

UPDATE angola
SET categoria='Transportes' WHERE categoria='Transportes e Servi�os';

INSERT INTO angola (produto, categoria, preco)
VALUES ('Internet (6 Mbps, plano, a cabo/ADSL)', 'Servi�os', 186.40),
('Tarifa de Chamada/minuto Prepago', 'Servi�os', 0.13),
('Electricidade, G�s, �gua, Lixo)', 'Servi�os', 78.03);

			/*atualiza��o da extens�o da atributo produto*/
				ALTER TABLE angola
				ALTER COLUMN produto VARCHAR (100);
				ALTER TABLE brasil
				ALTER COLUMN produto VARCHAR (100);
				ALTER TABLE cabo_verde
				ALTER COLUMN produto VARCHAR (100);
				ALTER TABLE mocambique
				ALTER COLUMN produto VARCHAR (100);
				ALTER TABLE portugal
				ALTER COLUMN produto VARCHAR (100);

INSERT INTO angola (produto, categoria, preco)
VALUES ('Compra de Casa no Sub�rbio (pre�o/m2)', 'Habita��o', 4067.36),
('Compra de Casa no Centro da Cidade (pre�o/m2)', 'Habita��o', 5136.51),
('Aluguer de Apartamento de 3 Quartos no Sub�rbio', 'Habita��o', 1306.79),
('Aluguer de Apartamento de 3 Quartos no Centro da Cidade', 'Habita��o', 6881.13),
('Aluguer de Apartamento de 1 Quarto no Centro da Cidade', 'Habita��o', 80.79),
('Aluguer de Apartamento de 1 Quarto no Centro da Cidade', 'Habita��o', 346.80);

UPDATE angola
SET produto='Aluguer de Apartamento de 1 Quarto no Sub�rbio' WHERE preco=80.79;

INSERT INTO angola (produto, categoria, preco)
VALUES ('Hipoteca: Taxa de Juros Anual (%)', 'Sal�rios', 0.25),
('Sal�rio M�dio L�quido', 'Sal�rios', 3276.62);

INSERT INTO angola (produto, categoria, preco)
VALUES ('Aluguel de Quadra de T�nis (1 hora)', 'Desporto', 16.75),
('Gin�sio (pre�o mensal)', 'Desporto', 40);

INSERT INTO angola (produto, categoria, preco)
VALUES ('Filmes (bilhete)', 'Recrea��o', 5.52),
('Ma�o de Cigarro (Marlboro)', 'Recrea��o', 2.15);

		/*Brasil*/
INSERT INTO brasil (produto, categoria, preco)
VALUES ('Cerveja Importada (330 mL)', 'Alimentos nos Supermercados', 2.43),
('Cerveja Nacional (0.5 L)', 'Alimentos nos Supermercados', 1.21),
('Garrafa de Vinho (qualidade m�dia)', 'Alimentos nos Supermercados', 9.06),
('Garrafa de �gua (1.5 L)', 'Alimentos nos Supermercados', 0.65),
('Alface (unidade)', 'Alimentos nos Supermercados', 0.69),
('Cebolas (1 kg)', 'Alimentos nos Supermercados', 1.01),
('Batatas (1 kg)', 'Alimentos nos Supermercados', 1.05),
('Tomates (1 kg)', 'Alimentos nos Supermercados', 1.58),
('Laranjas (1 kg)', 'Alimentos nos Supermercados', 0.93),
('Bananas (1 kg)', 'Alimentos nos Supermercados', 1.11),
('Ma��s (1 kg)', 'Alimentos nos Supermercados', 1.68),
('Queijo Fresco (1 kg)', 'Alimentos nos Supermercados', 8.54),
('Ovos (d�zia)', 'Alimentos nos Supermercados', 1.94),
('Arroz (1 kg)', 'Alimentos nos Supermercados', 1.13),
('P�o (1 kg)', 'Alimentos nos Supermercados', 1.42),
('Leite (1 L)', 'Alimentos nos Supermercados', 1.05);

INSERT INTO brasil (produto, categoria, preco)
VALUES ('Garrafa de �gua (330 mL)', 'Alimentos em Restaurantes', 0.65),
('Coca-Cola/Pepsi (330 mL)', 'Alimentos em Restaurantes', 1.05),
('Capuccino', 'Alimentos em Restaurantes', 1.58),
('Cerveja Importada (330 mL)', 'Alimentos em Restaurantes', 2.97),
('Cerveja Nacional (0.5 L)', 'Alimentos em Restaurantes', 1.78),
('Menu McDonalds, Burger Kings ou similares', 'Alimentos em Restaurantes', 6.33),
('Almo�o para Dois (2 pratos + sobremesa)', 'Alimentos em Restaurantes', 27.69),
('Almo�o em Restaurante Barato)', 'Alimentos em Restaurantes', 5.44);

INSERT INTO brasil (produto, categoria, preco)
VALUES ('Sapato de Couro Masculino', 'Vestu�rio e Cal�ados', 57.35),
('T�nis Desportivos de Marca (Nike, Adidas, etc.)', 'Vestu�rio e Cal�ados', 73.17),
('Vestido (unidade)', 'Vestu�rio e Cal�ados', 41.53),
('Cal�a Jeans', 'Vestu�rio e Cal�ados', 45.48);

INSERT INTO brasil (produto, categoria, preco)
VALUES ('Volkswagen Golf 1.4 de 90 kW (ou equivalente)', 'Transportes', 19775.43),
('Gasolina (1 L)', 'Transportes', 1.27),
('Uma Hora de T�xi (Bandeira 1)', 'Transportes', 6.53),
('T�xi Tarifa ao km (Bandeira 1)', 'Transportes', 0.79),
('Valor Inicial (Bandeira 1)', 'Transportes', 1.19),
('Passe de Transporte P�blico Mensal', 'Transportes', 43.51),
('Bilhete Unit�rio em Transporte P�blico', 'Transportes', 0.95);

INSERT INTO brasil(produto, categoria, preco)
VALUES ('Internet (6 Mbps, plano, a cabo/ADSL)', 'Servi�os', 20.17),
('Tarifa de Chamada/minuto Prepago', 'Servi�os', 0.29),
('Electricidade, G�s, �gua, Lixo)', 'Servi�os', 75.15);

INSERT INTO brasil (produto, categoria, preco)
VALUES ('Compra de Casa no Sub�rbio (pre�o/m2)', 'Habita��o', 1127.20),
('Compra de Casa no Centro da Cidade (pre�o/m2)', 'Habita��o', 1680.91),
('Aluguer de Apartamento de 3 Quartos no Sub�rbio', 'Habita��o', 435.06),
('Aluguer de Apartamento de 3 Quartos no Centro da Cidade', 'Habita��o', 593.26),
('Aluguer de Apartamento de 1 Quarto no Centro da Cidade', 'Habita��o', 197.75),
('Aluguer de Apartamento de 1 Quarto no Centro da Cidade', 'Habita��o', 316.41);

UPDATE brasil
SET produto='Aluguer de Apartamento de 1 Quarto no Sub�rbio' WHERE preco=197.75;

INSERT INTO brasil (produto, categoria, preco)
VALUES ('Hipoteca: Taxa de Juros Anual (%)', 'Sal�rios', 0.0965),
('Sal�rio M�dio L�quido', 'Sal�rios', 415.28);

INSERT INTO brasil (produto, categoria, preco)
VALUES ('Aluguel de Quadra de T�nis (1 hora)', 'Desporto', 23.02),
('Gin�sio (pre�o mensal)', 'Desporto', 22.54);

INSERT INTO brasil (produto, categoria, preco)
VALUES ('Filmes (bilhete)', 'Recrea��o', 6.53),
('Ma�o de Cigarro (Marlboro)', 'Recrea��o', 2.37);

		/*Cabo Verde*/
INSERT INTO cabo_verde(produto, categoria, preco)
VALUES ('Cerveja Importada (330 mL)', 'Alimentos nos Supermercados', 1.51),
('Cerveja Nacional (0.5 L)', 'Alimentos nos Supermercados', 1.86),
('Garrafa de Vinho (qualidade m�dia)', 'Alimentos nos Supermercados', 6.38),
('Garrafa de �gua (1.5 L)', 'Alimentos nos Supermercados', 0.83),
('Alface (unidade)', 'Alimentos nos Supermercados', 1.54),
('Cebolas (1 kg)', 'Alimentos nos Supermercados', 1.61),
('Batatas (1 kg)', 'Alimentos nos Supermercados', 1.41),
('Tomates (1 kg)', 'Alimentos nos Supermercados', 3.39),
('Laranjas (1 kg)', 'Alimentos nos Supermercados', 2.39),
('Bananas (1 kg)', 'Alimentos nos Supermercados', 2.09),
('Ma��s (1 kg)', 'Alimentos nos Supermercados', 2.49),
('Queijo Fresco (1 kg)', 'Alimentos nos Supermercados', 5.98),
('Ovos (d�zia)', 'Alimentos nos Supermercados', 2.39),
('Arroz (1 kg)', 'Alimentos nos Supermercados', 1.33),
('P�o (1 kg)', 'Alimentos nos Supermercados', 1.42),
('Leite (1 L)', 'Alimentos nos Supermercados', 1.00);

INSERT INTO cabo_verde(produto, categoria, preco)
VALUES ('Garrafa de �gua (330 mL)', 'Alimentos em Restaurantes', 0.86),
('Coca-Cola/Pepsi (330 mL)', 'Alimentos em Restaurantes', 1.26),
('Capuccino', 'Alimentos em Restaurantes', 1.29),
('Cerveja Importada (330 mL)', 'Alimentos em Restaurantes', 1.65),
('Cerveja Nacional (0.5 L)', 'Alimentos em Restaurantes', 2.99),
('Menu McDonalds, Burger Kings ou similares', 'Alimentos em Restaurantes', 5.49),
('Almo�o para Dois (2 pratos + sobremesa)', 'Alimentos em Restaurantes', 40.89),
('Almo�o em Restaurante Barato)', 'Alimentos em Restaurantes', 4.69);

INSERT INTO cabo_verde (produto, categoria, preco)
VALUES ('Sapato de Couro Masculino', 'Vestu�rio e Cal�ados', 147.62),
('T�nis Desportivos de Marca (Nike, Adidas, etc.)', 'Vestu�rio e Cal�ados', 78.80),
('Vestido (unidade)', 'Vestu�rio e Cal�ados', 29.92),
('Cal�a Jeans', 'Vestu�rio e Cal�ados', 29.92);

INSERT INTO cabo_verde(produto, categoria, preco)
VALUES ('Volkswagen Golf 1.4 de 90 kW (ou equivalente)', 'Transportes', 26612.03),
('Gasolina (1 L)', 'Transportes', 1.50),
('Uma Hora de T�xi (Bandeira 1)', 'Transportes', 9.87),
('T�xi Tarifa ao km (Bandeira 1)', 'Transportes', 1.73),
('Valor Inicial (Bandeira 1)', 'Transportes', 1.48),
('Passe de Transporte P�blico Mensal', 'Transportes', 20.95),
('Bilhete Unit�rio em Transporte P�blico', 'Transportes', 0.88);

INSERT INTO cabo_verde(produto, categoria, preco)
VALUES ('Internet (6 Mbps, plano, a cabo/ADSL)', 'Servi�os', 56.85),
('Tarifa de Chamada/minuto Prepago', 'Servi�os', 0.34),
('Electricidade, G�s, �gua, Lixo)', 'Servi�os', 82.79);

INSERT INTO cabo_verde(produto, categoria, preco)
VALUES ('Compra de Casa no Sub�rbio (pre�o/m2)', 'Habita��o', 681.23),
('Compra de Casa no Centro da Cidade (pre�o/m2)', 'Habita��o', 929.59),
('Aluguer de Apartamento de 3 Quartos no Sub�rbio', 'Habita��o', 296.23),
('Aluguer de Apartamento de 3 Quartos no Centro da Cidade', 'Habita��o', 431.88),
('Aluguer de Apartamento de 1 Quarto no Centro da Cidade', 'Habita��o', 173.55),
('Aluguer de Apartamento de 1 Quarto no Centro da Cidade', 'Habita��o', 293.24);

UPDATE cabo_verde
SET produto='Aluguer de Apartamento de 1 Quarto no Sub�rbio' WHERE preco=173.55;

INSERT INTO cabo_verde (produto, categoria, preco)
VALUES ('Hipoteca: Taxa de Juros Anual (%)', 'Sal�rios', 0.1633),
('Sal�rio M�dio L�quido', 'Sal�rios', 285.26);

INSERT INTO cabo_verde(produto, categoria, preco)
VALUES ('Aluguel de Quadra de T�nis (1 hora)', 'Desporto', 4.89),
('Gin�sio (pre�o mensal)', 'Desporto', 31.92);

INSERT INTO cabo_verde(produto, categoria, preco)
VALUES ('Filmes (bilhete)', 'Recrea��o', 5.88),
('Ma�o de Cigarro (Marlboro)', 'Recrea��o', 4.39);

		/*Mo�ambique*/
INSERT INTO mocambique (produto, categoria, preco)
VALUES ('Cerveja Importada (330 mL)', 'Alimentos nos Supermercados', 1.82),
('Cerveja Nacional (0.5 L)', 'Alimentos nos Supermercados', 1.03),
('Garrafa de Vinho (qualidade m�dia)', 'Alimentos nos Supermercados', 14.07),
('Garrafa de �gua (1.5 L)', 'Alimentos nos Supermercados', 0.78),
('Alface (unidade)', 'Alimentos nos Supermercados', 0.76),
('Cebolas (1 kg)', 'Alimentos nos Supermercados', 1.17),
('Batatas (1 kg)', 'Alimentos nos Supermercados', 0.82),
('Tomates (1 kg)', 'Alimentos nos Supermercados', 1.57),
('Laranjas (1 kg)', 'Alimentos nos Supermercados', 1.41),
('Bananas (1 kg)', 'Alimentos nos Supermercados', 0.89),
('Ma��s (1 kg)', 'Alimentos nos Supermercados', 1.93),
('Queijo Fresco (1 kg)', 'Alimentos nos Supermercados', 17.39),
('Ovos (d�zia)', 'Alimentos nos Supermercados', 1.99),
('Arroz (1 kg)', 'Alimentos nos Supermercados', 1.25),
('P�o (1 kg)', 'Alimentos nos Supermercados', 1.11),
('Leite (1 L)', 'Alimentos nos Supermercados', 1.55);

INSERT INTO mocambique(produto, categoria, preco)
VALUES ('Garrafa de �gua (330 mL)', 'Alimentos em Restaurantes', 0.69),
('Coca-Cola/Pepsi (330 mL)', 'Alimentos em Restaurantes', 1.03),
('Capuccino', 'Alimentos em Restaurantes', 1.80),
('Cerveja Importada (330 mL)', 'Alimentos em Restaurantes', 1.57),
('Cerveja Nacional (0.5 L)', 'Alimentos em Restaurantes', 0.93),
('Menu McDonalds, Burger Kings ou similares', 'Alimentos em Restaurantes', 3.95),
('Almo�o para Dois (2 pratos + sobremesa)', 'Alimentos em Restaurantes', 55.34),
('Almo�o em Restaurante Barato)', 'Alimentos em Restaurantes', 10.91);

INSERT INTO mocambique(produto, categoria, preco)
VALUES ('Sapato de Couro Masculino', 'Vestu�rio e Cal�ados', 96.44),
('T�nis Desportivos de Marca (Nike, Adidas, etc.)', 'Vestu�rio e Cal�ados', 66.40),
('Vestido (unidade)', 'Vestu�rio e Cal�ados', 69.56),
('Cal�a Jeans', 'Vestu�rio e Cal�ados', 25.30);

INSERT INTO mocambique(produto, categoria, preco)
VALUES ('Volkswagen Golf 1.4 de 90 kW (ou equivalente)', 'Transportes', 32894.66),
('Gasolina (1 L)', 'Transportes', 1.19),
('Uma Hora de T�xi (Bandeira 1)', 'Transportes', 25.30),
('T�xi Tarifa ao km (Bandeira 1)', 'Transportes', 3.95),
('Valor Inicial (Bandeira 1)', 'Transportes', 3.48),
('Passe de Transporte P�blico Mensal', 'Transportes', 13.12),
('Bilhete Unit�rio em Transporte P�blico', 'Transportes', 0.26);

INSERT INTO mocambique(produto, categoria, preco)
VALUES ('Internet (6 Mbps, plano, a cabo/ADSL)', 'Servi�os', 118.58),
('Tarifa de Chamada/minuto Prepago', 'Servi�os', 0.06),
('Electricidade, G�s, �gua, Lixo)', 'Servi�os', 77.47);

INSERT INTO mocambique(produto, categoria, preco)
VALUES ('Compra de Casa no Sub�rbio (pre�o/m2)', 'Habita��o', 1932),
('Compra de Casa no Centro da Cidade (pre�o/m2)', 'Habita��o', 3248.99),
('Aluguer de Apartamento de 3 Quartos no Sub�rbio', 'Habita��o', 1163.63),
('Aluguer de Apartamento de 3 Quartos no Centro da Cidade', 'Habita��o', 1783.39),
('Aluguer de Apartamento de 1 Quarto no Centro da Cidade', 'Habita��o', 260.87),
('Aluguer de Apartamento de 1 Quarto no Centro da Cidade', 'Habita��o', 926.48);

UPDATE mocambique
SET produto='Aluguer de Apartamento de 1 Quarto no Sub�rbio' WHERE preco=260.87

INSERT INTO mocambique(produto, categoria, preco)
VALUES ('Hipoteca: Taxa de Juros Anual (%)', 'Sal�rios', 0.2586),
('Sal�rio M�dio L�quido', 'Sal�rios', 219.6);

INSERT INTO mocambique(produto, categoria, preco)
VALUES ('Aluguel de Quadra de T�nis (1 hora)', 'Desporto', 26.88),
('Gin�sio (pre�o mensal)', 'Desporto', 58.50);

INSERT INTO mocambique(produto, categoria, preco)
VALUES ('Filmes (bilhete)', 'Recrea��o', 6.32),
('Ma�o de Cigarro (Marlboro)', 'Recrea��o', 2.36);


		/*Portugal*/
INSERT INTO portugal(produto, categoria, preco)
VALUES ('Cerveja Importada (330 mL)', 'Alimentos nos Supermercados', 2.05),
('Cerveja Nacional (0.5 L)', 'Alimentos nos Supermercados', 1.20),
('Garrafa de Vinho (qualidade m�dia)', 'Alimentos nos Supermercados', 4.40),
('Garrafa de �gua (1.5 L)', 'Alimentos nos Supermercados', 0.64),
('Alface (unidade)', 'Alimentos nos Supermercados', 1.20),
('Cebolas (1 kg)', 'Alimentos nos Supermercados', 1.33),
('Batatas (1 kg)', 'Alimentos nos Supermercados', 1.20),
('Tomates (1 kg)', 'Alimentos nos Supermercados', 1.95),
('Laranjas (1 kg)', 'Alimentos nos Supermercados', 1.50),
('Bananas (1 kg)', 'Alimentos nos Supermercados', 1.30),
('Ma��s (1 kg)', 'Alimentos nos Supermercados', 1.89),
('Queijo Fresco (1 kg)', 'Alimentos nos Supermercados', 8.80),
('Ovos (d�zia)', 'Alimentos nos Supermercados', 2.52),
('Arroz (1 kg)', 'Alimentos nos Supermercados', 1.23),
('P�o (1 kg)', 'Alimentos nos Supermercados', 1.34),
('Leite (1 L)', 'Alimentos nos Supermercados', 0.88);

INSERT INTO portugal(produto, categoria, preco)
VALUES ('Garrafa de �gua (330 mL)', 'Alimentos em Restaurantes', 1.13),
('Coca-Cola/Pepsi (330 mL)', 'Alimentos em Restaurantes', 1.57),
('Capuccino', 'Alimentos em Restaurantes', 1.62),
('Cerveja Importada (330 mL)', 'Alimentos em Restaurantes', 2.31),
('Cerveja Nacional (0.5 L)', 'Alimentos em Restaurantes', 2.20),
('Menu McDonalds, Burger Kings ou similares', 'Alimentos em Restaurantes', 7.70),
('Almo�o para Dois (2 pratos + sobremesa)', 'Alimentos em Restaurantes', 43.98),
('Almo�o em Restaurante Barato)', 'Alimentos em Restaurantes', 9.90);

INSERT INTO portugal(produto, categoria, preco)
VALUES ('Sapato de Couro Masculino', 'Vestu�rio e Cal�ados', 86.87),
('T�nis Desportivos de Marca (Nike, Adidas, etc.)', 'Vestu�rio e Cal�ados', 73.67),
('Vestido (unidade)', 'Vestu�rio e Cal�ados', 33.32),
('Cal�a Jeans', 'Vestu�rio e Cal�ados', 81.37);

INSERT INTO portugal(produto, categoria, preco)
VALUES ('Volkswagen Golf 1.4 de 90 kW (ou equivalente)', 'Transportes', 29689.77),
('Gasolina (1 L)', 'Transportes', 2.09),
('Uma Hora de T�xi (Bandeira 1)', 'Transportes', 16.49),
('T�xi Tarifa ao km (Bandeira 1)', 'Transportes', 0.88),
('Valor Inicial (Bandeira 1)', 'Transportes', 3.85),
('Passe de Transporte P�blico Mensal', 'Transportes', 43.98),
('Bilhete Unit�rio em Transporte P�blico', 'Transportes', 1.87);

INSERT INTO portugal(produto, categoria, preco)
VALUES ('Internet (6 Mbps, plano, a cabo/ADSL)', 'Servi�os', 38.49),
('Tarifa de Chamada/minuto Prepago', 'Servi�os', 0.16),
('Electricidade, G�s, �gua, Lixo)', 'Servi�os', 123.16);

INSERT INTO portugal(produto, categoria, preco)
VALUES ('Compra de Casa no Sub�rbio (pre�o/m2)', 'Habita��o', 2199.24),
('Compra de Casa no Centro da Cidade (pre�o/m2)', 'Habita��o', 3188.90),
('Aluguer de Apartamento de 3 Quartos no Sub�rbio', 'Habita��o', 1055.64),
('Aluguer de Apartamento de 3 Quartos no Centro da Cidade', 'Habita��o', 1429.51),
('Aluguer de Apartamento de 1 Quarto no Sub�rbio', 'Habita��o', 648.78),
('Aluguer de Apartamento de 1 Quarto no Centro da Cidade', 'Habita��o', 846.71);

INSERT INTO portugal (produto, categoria, preco)
VALUES ('Hipoteca: Taxa de Juros Anual (%)', 'Sal�rios', 0.0225),
('Sal�rio M�dio L�quido', 'Sal�rios', 1088.63);

INSERT INTO portugal (produto, categoria, preco)
VALUES ('Aluguel de Quadra de T�nis (1 hora)', 'Desporto', 12.76),
('Gin�sio (pre�o mensal)', 'Desporto', 37.94);

INSERT INTO portugal (produto, categoria, preco)
VALUES ('Filmes (bilhete)', 'Recrea��o', 7.70),
('Ma�o de Cigarro (Marlboro)', 'Recrea��o', 5.61);


/*Query a ser alimentada no Power BI*/
WITH custo_de_vida_cplp_2023 AS ( 
SELECT * FROM angola
UNION
SELECT * FROM brasil
UNION
SELECT * FROM cabo_verde
UNION
SELECT * FROM mocambique
UNION
SELECT * FROM portugal)

SELECT * FROM custo_de_vida_cplp_2023;























